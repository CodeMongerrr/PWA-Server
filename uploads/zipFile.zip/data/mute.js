window.YTD.mute.part0 = [
  {
    "muting" : {
      "accountId" : "333357345",
      "userLink" : "https://twitter.com/intent/user?user_id=333357345"
    }
  }
]