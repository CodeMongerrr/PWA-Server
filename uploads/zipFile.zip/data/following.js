window.YTD.following.part0 = [
  {
    "following" : {
      "accountId" : "1381967280414679044",
      "userLink" : "https://twitter.com/intent/user?user_id=1381967280414679044"
    }
  },
  {
    "following" : {
      "accountId" : "1512713123622498305",
      "userLink" : "https://twitter.com/intent/user?user_id=1512713123622498305"
    }
  },
  {
    "following" : {
      "accountId" : "964919649837056000",
      "userLink" : "https://twitter.com/intent/user?user_id=964919649837056000"
    }
  },
  {
    "following" : {
      "accountId" : "2455740283",
      "userLink" : "https://twitter.com/intent/user?user_id=2455740283"
    }
  },
  {
    "following" : {
      "accountId" : "1281318152438198272",
      "userLink" : "https://twitter.com/intent/user?user_id=1281318152438198272"
    }
  },
  {
    "following" : {
      "accountId" : "259379883",
      "userLink" : "https://twitter.com/intent/user?user_id=259379883"
    }
  },
  {
    "following" : {
      "accountId" : "313724502",
      "userLink" : "https://twitter.com/intent/user?user_id=313724502"
    }
  },
  {
    "following" : {
      "accountId" : "95092020",
      "userLink" : "https://twitter.com/intent/user?user_id=95092020"
    }
  },
  {
    "following" : {
      "accountId" : "44196397",
      "userLink" : "https://twitter.com/intent/user?user_id=44196397"
    }
  },
  {
    "following" : {
      "accountId" : "1221927642850611203",
      "userLink" : "https://twitter.com/intent/user?user_id=1221927642850611203"
    }
  },
  {
    "following" : {
      "accountId" : "4860635361",
      "userLink" : "https://twitter.com/intent/user?user_id=4860635361"
    }
  },
  {
    "following" : {
      "accountId" : "1368743841122115587",
      "userLink" : "https://twitter.com/intent/user?user_id=1368743841122115587"
    }
  },
  {
    "following" : {
      "accountId" : "1468549645957689344",
      "userLink" : "https://twitter.com/intent/user?user_id=1468549645957689344"
    }
  },
  {
    "following" : {
      "accountId" : "1240237444945121280",
      "userLink" : "https://twitter.com/intent/user?user_id=1240237444945121280"
    }
  },
  {
    "following" : {
      "accountId" : "2312333412",
      "userLink" : "https://twitter.com/intent/user?user_id=2312333412"
    }
  },
  {
    "following" : {
      "accountId" : "295218901",
      "userLink" : "https://twitter.com/intent/user?user_id=295218901"
    }
  }
]