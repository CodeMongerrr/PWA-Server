window.YTD.block.part0 = [
  {
    "blocking" : {
      "accountId" : "1519337397905141762",
      "userLink" : "https://twitter.com/intent/user?user_id=1519337397905141762"
    }
  },
  {
    "blocking" : {
      "accountId" : "831994506186780678",
      "userLink" : "https://twitter.com/intent/user?user_id=831994506186780678"
    }
  }
]