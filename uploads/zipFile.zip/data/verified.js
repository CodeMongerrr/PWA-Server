window.YTD.verified.part0 = [
  {
    "verified" : {
      "accountId" : "1639610498680492032",
      "verified" : false
    }
  }
]