window.YTD.professional_data.part0 = [
  {
    "professionalData" : {
      "professionalType" : "Business",
      "appSpotlight" : [ ],
      "accountId" : "1639610498680492032",
      "linkSpotlight" : [ ],
      "creationSource" : "NavDrawer",
      "professionalId" : "1680954707089686535",
      "categories" : [
        {
          "categoryName" : "Mobile Application",
          "setToDisplay" : true
        }
      ],
      "createdAt" : "2023-07-17T14:56:47.457Z",
      "locationSpotlight" : [ ]
    }
  }
]