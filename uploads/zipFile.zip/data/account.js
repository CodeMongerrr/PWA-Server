window.YTD.account.part0 = [
  {
    "account" : {
      "email" : "21je0056@iitism.ac.in",
      "createdVia" : "oauth:3033300",
      "username" : "AdityaRosh31704",
      "accountId" : "1639610498680492032",
      "createdAt" : "2023-03-25T12:49:49.770Z",
      "accountDisplayName" : "Aditya Roshan Joshi"
    }
  }
]