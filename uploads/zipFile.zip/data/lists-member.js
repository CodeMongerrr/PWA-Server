window.YTD.lists_member.part0 = [
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Gavin_Canine/lists/1642272867638190083"
    }
  }
]