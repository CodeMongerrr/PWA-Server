window.YTD.connected_application.part0 = [
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Twitter, Inc.",
        "url" : ""
      },
      "name" : "Twitter for Android",
      "description" : "Twitter for Android",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2023-04-11T19:35:05.000Z",
      "id" : "258901"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : ""
      },
      "name" : "1680875797991796737AdityaRosh3",
      "description" : "This app was created to use the Twitter API.",
      "permissions" : [
        "read"
      ],
      "approvedAt" : "2023-07-17T10:36:53.000Z",
      "id" : "27485216"
    }
  }
]