window.YTD.tweet_headers.part0 = [
  {
    "tweet" : {
      "tweet_id" : "1680903105561661440",
      "user_id" : "1639610498680492032",
      "created_at" : "Mon Jul 17 11:31:44 +0000 2023"
    }
  },
  {
    "tweet" : {
      "tweet_id" : "1680903065422168064",
      "user_id" : "1639610498680492032",
      "created_at" : "Mon Jul 17 11:31:35 +0000 2023"
    }
  },
  {
    "tweet" : {
      "tweet_id" : "1648231332743622657",
      "user_id" : "1639610498680492032",
      "created_at" : "Tue Apr 18 07:45:47 +0000 2023"
    }
  }
]