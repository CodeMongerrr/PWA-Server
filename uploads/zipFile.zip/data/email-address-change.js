window.YTD.email_address_change.part0 = [
  {
    "emailAddressChange" : {
      "accountId" : "1639610498680492032",
      "emailChange" : {
        "changedAt" : "2023-03-25T12:49:49.000Z",
        "changedTo" : "21je0056@iitism.ac.in"
      }
    }
  }
]