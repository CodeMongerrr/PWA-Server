window.YTD.personalization.part0 = [
  {
    "p13nData" : {
      "demographics" : {
        "languages" : [
          {
            "language" : "English",
            "isDisabled" : false
          }
        ],
        "genderInfo" : {
          "gender" : "male"
        }
      },
      "interests" : {
        "interests" : [
          {
            "name" : "Action & adventure films",
            "isDisabled" : false
          },
          {
            "name" : "Andrew Tate",
            "isDisabled" : false
          },
          {
            "name" : "Anthony Albanese",
            "isDisabled" : false
          },
          {
            "name" : "Apple",
            "isDisabled" : false
          },
          {
            "name" : "Athletic apparel",
            "isDisabled" : false
          },
          {
            "name" : "Australia government institutions",
            "isDisabled" : false
          },
          {
            "name" : "Australia politics",
            "isDisabled" : false
          },
          {
            "name" : "Business personalities",
            "isDisabled" : false
          },
          {
            "name" : "COVID-19",
            "isDisabled" : false
          },
          {
            "name" : "Casey Neistat",
            "isDisabled" : false
          },
          {
            "name" : "Central Banks",
            "isDisabled" : false
          },
          {
            "name" : "Cereals",
            "isDisabled" : false
          },
          {
            "name" : "Charlie Sheen",
            "isDisabled" : false
          },
          {
            "name" : "ChatGPT",
            "isDisabled" : false
          },
          {
            "name" : "Cheerios",
            "isDisabled" : false
          },
          {
            "name" : "Cult classics",
            "isDisabled" : false
          },
          {
            "name" : "Cybersecurity",
            "isDisabled" : false
          },
          {
            "name" : "Disney",
            "isDisabled" : false
          },
          {
            "name" : "Elon Musk",
            "isDisabled" : false
          },
          {
            "name" : "Entertainment",
            "isDisabled" : false
          },
          {
            "name" : "Entertainment franchises",
            "isDisabled" : false
          },
          {
            "name" : "Entertainment industry",
            "isDisabled" : false
          },
          {
            "name" : "Family",
            "isDisabled" : false
          },
          {
            "name" : "Fashion",
            "isDisabled" : false
          },
          {
            "name" : "Firefighting",
            "isDisabled" : false
          },
          {
            "name" : "Global Economy",
            "isDisabled" : false
          },
          {
            "name" : "Government institutions",
            "isDisabled" : false
          },
          {
            "name" : "India national news",
            "isDisabled" : false
          },
          {
            "name" : "India political figures",
            "isDisabled" : false
          },
          {
            "name" : "India politics",
            "isDisabled" : false
          },
          {
            "name" : "Industries",
            "isDisabled" : false
          },
          {
            "name" : "Information security",
            "isDisabled" : false
          },
          {
            "name" : "Jordan Peterson",
            "isDisabled" : false
          },
          {
            "name" : "Marques Brownlee",
            "isDisabled" : false
          },
          {
            "name" : "Marvel Universe",
            "isDisabled" : false
          },
          {
            "name" : "Memes",
            "isDisabled" : false
          },
          {
            "name" : "Movies",
            "isDisabled" : false
          },
          {
            "name" : "Movies & TV",
            "isDisabled" : false
          },
          {
            "name" : "Nike",
            "isDisabled" : false
          },
          {
            "name" : "Office of the Australian Prime Minister",
            "isDisabled" : false
          },
          {
            "name" : "OpenAI",
            "isDisabled" : false
          },
          {
            "name" : "Pirates of the Caribbean",
            "isDisabled" : false
          },
          {
            "name" : "Political figures",
            "isDisabled" : false
          },
          {
            "name" : "Political issues",
            "isDisabled" : false
          },
          {
            "name" : "Politics",
            "isDisabled" : false
          },
          {
            "name" : "Romance films",
            "isDisabled" : false
          },
          {
            "name" : "Social media",
            "isDisabled" : false
          },
          {
            "name" : "Stanford University",
            "isDisabled" : false
          },
          {
            "name" : "Superhero films",
            "isDisabled" : false
          },
          {
            "name" : "Tech personalities",
            "isDisabled" : false
          },
          {
            "name" : "Technology",
            "isDisabled" : false
          },
          {
            "name" : "The Reserve Bank of India",
            "isDisabled" : false
          },
          {
            "name" : "Titanic",
            "isDisabled" : false
          },
          {
            "name" : "Twitter",
            "isDisabled" : false
          },
          {
            "name" : "UPS",
            "isDisabled" : false
          },
          {
            "name" : "Web3",
            "isDisabled" : false
          },
          {
            "name" : "Weddings",
            "isDisabled" : false
          },
          {
            "name" : "WhatsApp",
            "isDisabled" : false
          },
          {
            "name" : "YouTubers",
            "isDisabled" : false
          }
        ],
        "partnerInterests" : [ ],
        "audienceAndAdvertisers" : {
          "lookalikeAdvertisers" : [ ],
          "advertisers" : [ ],
          "doNotReachAdvertisers" : [ ],
          "catalogAudienceAdvertisers" : [ ],
          "numAudiences" : "0"
        },
        "shows" : [ ]
      },
      "locationHistory" : [
        "Mumbai, India"
      ],
      "inferredAgeInfo" : {
        "age" : [
          "13-54"
        ],
        "birthDate" : ""
      }
    }
  }
]