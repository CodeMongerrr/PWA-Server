window.YTD.account_timezone.part0 = [
  {
    "accountTimezone" : {
      "accountId" : "1639610498680492032"
    }
  }
]