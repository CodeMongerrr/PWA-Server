window.YTD.profile.part0 = [
  {
    "profile" : {
      "description" : {
        "bio" : "Blockchain Developer | Python Enthusiast | Robotics | Data Analyst |",
        "website" : "",
        "location" : "Thane, Maharashtra"
      },
      "avatarMediaUrl" : "https://pbs.twimg.com/profile_images/1639610890621423618/8LNVaikA.jpg",
      "headerMediaUrl" : "https://pbs.twimg.com/profile_banners/1639610498680492032/1679748706"
    }
  }
]