window.YTD.twitter_circle.part0 = [
  {
    "twitterCircle" : {
      "id" : "1639614745115516928",
      "ownerUserId" : "1639610498680492032",
      "createdAt" : "2023-03-25T13:06:32.463Z"
    }
  }
]