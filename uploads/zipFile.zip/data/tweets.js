window.YTD.tweets.part0 = [
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1680903105561661440"
          ],
          "editableUntil" : "2023-07-17T12:31:44.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "26"
      ],
      "favorite_count" : "0",
      "id_str" : "1680903105561661440",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1680903105561661440",
      "created_at" : "Mon Jul 17 11:31:44 +0000 2023",
      "favorited" : false,
      "full_text" : "developer testing going on",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1680903065422168064"
          ],
          "editableUntil" : "2023-07-17T12:31:35.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "5"
      ],
      "favorite_count" : "1",
      "id_str" : "1680903065422168064",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1680903065422168064",
      "created_at" : "Mon Jul 17 11:31:35 +0000 2023",
      "favorited" : false,
      "full_text" : "hello",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1648231332743622657"
          ],
          "editableUntil" : "2023-04-18T08:15:47.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Dr Jordan B Peterson",
            "screen_name" : "jordanbpeterson",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "95092020",
            "id" : "95092020"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "102"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1648084151264849924",
      "id_str" : "1648231332743622657",
      "in_reply_to_user_id" : "95092020",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1648231332743622657",
      "in_reply_to_status_id" : "1648084151264849924",
      "created_at" : "Tue Apr 18 07:45:47 +0000 2023",
      "favorited" : false,
      "full_text" : "@jordanbpeterson Give each person a unique public address hash and let them use it for identification.",
      "lang" : "en",
      "in_reply_to_screen_name" : "jordanbpeterson",
      "in_reply_to_user_id_str" : "95092020"
    }
  }
]