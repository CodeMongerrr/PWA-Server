window.YTD.ad_impressions.part0 = [
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Android",
                "deviceId" : "RI7zRRFAi6bh65Z6/AvgZFOayJWvRQ8IjDKSaJsS+/s="
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1647982874363146240",
                "tweetText" : "Follow for official updates directly from Filecoin 🗣️ and join the launch of Filecoin Virtual Machine (FVM) to revolutionize the data economy! 🚀 https://t.co/ee2owHUlVp",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/ee2owHUlVp"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Filecoin Ecosystem",
                "screenName" : "@Filecoin"
              },
              "impressionTime" : "2023-04-19 17:56:01"
            },
            {
              "deviceInfo" : {
                "osType" : "Android",
                "deviceId" : "RI7zRRFAi6bh65Z6/AvgZFOayJWvRQ8IjDKSaJsS+/s="
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1645364972782858241",
                "tweetText" : "GM Frens 🖖🏼 comment  👑👑  like 👑👑 retweet  👑👑👑👑  follow the King of COSPLAY 🎭 👉🏻 @g13m 👑👑👑👑 https://t.co/PX0kyS7UVd",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/PX0kyS7UVd"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "LoveMake.eth",
                "screenName" : "@g13m"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                }
              ],
              "impressionTime" : "2023-04-19 17:54:50"
            },
            {
              "deviceInfo" : {
                "osType" : "Android",
                "deviceId" : "RI7zRRFAi6bh65Z6/AvgZFOayJWvRQ8IjDKSaJsS+/s="
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1624629481142112257",
                "tweetText" : "मध्य प्रदेश अनेक दिलचस्प कहानियों से समृद्ध है इसलिए \nहम आपके लिए लेकर आये हैं, एक नई सीरीज़ 'मध्य प्रदेश की कहानियाँ' जिसमें हम आपको प्रदेश के आकर्षक पर्यटन स्थलों और उनसे जुड़ी रोचक कहानियों के बारे में बताएंगे। \nआइये इस कड़ी में सबसे पहले जाने 'भीमकुंड' के बारे में।\n#MPTourism https://t.co/lZT8MAuxhk",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/lZT8MAuxhk"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Madhya Pradesh Tourism",
                "screenName" : "@MPTourism"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                }
              ],
              "impressionTime" : "2023-04-19 17:56:02"
            },
            {
              "deviceInfo" : {
                "osType" : "Android",
                "deviceId" : "RI7zRRFAi6bh65Z6/AvgZFOayJWvRQ8IjDKSaJsS+/s="
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1639323245026344960",
                "tweetText" : "Calling all audiophiles to join the Snapdragon Insiders community. Follow @snapdragon_in to access extraordinary music experiences.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Snapdragon India",
                "screenName" : "@Snapdragon_IN"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                }
              ],
              "impressionTime" : "2023-04-19 17:54:51"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Android",
                "deviceId" : "RI7zRRFAi6bh65Z6/AvgZFOayJWvRQ8IjDKSaJsS+/s="
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1609293473668022272",
                "tweetText" : "We work to empower communities and enhance #QualityOfLife in diverse fields, from sports to agriculture, among others. \n\nFollow us to learn more👇",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "aramco",
                "screenName" : "@aramco"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                }
              ],
              "impressionTime" : "2023-04-23 05:02:28"
            },
            {
              "deviceInfo" : {
                "osType" : "Android",
                "deviceId" : "RI7zRRFAi6bh65Z6/AvgZFOayJWvRQ8IjDKSaJsS+/s="
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1647930611384893440",
                "tweetText" : "Zoya Akhtar, Rakeysh Omprakash Mehra and Imtiaz Ali are waiting to mentor* you. Time to follow @Snapdragon_in and participate in our film contest to get a chance to learn from the experts. T&amp;C apply*. https://t.co/tQ51fU8F1w",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/tQ51fU8F1w"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Snapdragon India",
                "screenName" : "@Snapdragon_IN"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                }
              ],
              "impressionTime" : "2023-04-23 05:03:16"
            },
            {
              "deviceInfo" : {
                "osType" : "Android",
                "deviceId" : "RI7zRRFAi6bh65Z6/AvgZFOayJWvRQ8IjDKSaJsS+/s="
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1649061030402617347",
                "tweetText" : "📰  Filecoin News 65 https://t.co/D50ETJ8nNz\n\nHighlights\n⚡ Network v19 Lightening and nv20 Thunder\n🤝 FEVM + Brave Wallet\n📊 @MessariCrypto State of Filecoin Q1 2023\n🎥 VideoJam Hackathon\n🛠️ The FVM Imaginarium: Developer Tooling, Hackathons and other Opportunities for Builders https://t.co/ghZLbtgyQP",
                "urls" : [
                  "https://t.co/D50ETJ8nNz"
                ],
                "mediaUrls" : [
                  "https://t.co/ghZLbtgyQP"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Filecoin Ecosystem",
                "screenName" : "@Filecoin"
              },
              "impressionTime" : "2023-04-23 05:06:52"
            },
            {
              "deviceInfo" : {
                "osType" : "Android",
                "deviceId" : "RI7zRRFAi6bh65Z6/AvgZFOayJWvRQ8IjDKSaJsS+/s="
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1646789847401762816",
                "tweetText" : "Nidhi was looking for a quality phone. Then she discovered iPhone.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Apple",
                "screenName" : "@Apple"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Android"
                }
              ],
              "impressionTime" : "2023-04-23 05:06:18"
            },
            {
              "deviceInfo" : {
                "osType" : "Android",
                "deviceId" : "RI7zRRFAi6bh65Z6/AvgZFOayJWvRQ8IjDKSaJsS+/s="
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1641456238813904903",
                "tweetText" : "Don't get stumped by our IPL 2023 quiz! Pick your favourite team and see if you are a true expert.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "CricketNews.com",
                "screenName" : "@cricketnews_com"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Dhanbad"
                }
              ],
              "impressionTime" : "2023-04-23 04:59:54"
            },
            {
              "deviceInfo" : {
                "osType" : "Android",
                "deviceId" : "RI7zRRFAi6bh65Z6/AvgZFOayJWvRQ8IjDKSaJsS+/s="
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1476173983880028164",
                "tweetText" : "Women have suffered throughout human history from various severe forms of abuse and marginalization.” Dr. Al-Issa clarifies the true position of Islam towards women.  Follow his efforts around the world in this field.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Mohammed Al-Issa محمد العيسى",
                "screenName" : "@MhmdAlissa"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                }
              ],
              "impressionTime" : "2023-04-23 04:58:52"
            },
            {
              "deviceInfo" : {
                "osType" : "Android",
                "deviceId" : "RI7zRRFAi6bh65Z6/AvgZFOayJWvRQ8IjDKSaJsS+/s="
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1641923574931030017",
                "tweetText" : "These next few months will be packed with pure passion. Follow our page to stay up to date with all the latest news on Inter! 🖤💙 https://t.co/Va28w0FkWQ",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/Va28w0FkWQ",
                  "https://t.co/Va28w0FkWQ"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Inter",
                "screenName" : "@Inter"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                }
              ],
              "impressionTime" : "2023-04-23 04:58:52"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Bitget",
                "screenName" : "@bitgetglobal"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Business & finance"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Elon Musk"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Cryptocurrencies"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                }
              ],
              "impressionTime" : "2023-05-24 05:24:42"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Bitget",
                "screenName" : "@bitgetglobal"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Business & finance"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Elon Musk"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Cryptocurrencies"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                }
              ],
              "impressionTime" : "2023-05-24 08:53:33"
            },
            {
              "deviceInfo" : {
                "osType" : "Android",
                "deviceId" : "RI7zRRFAi6bh65Z6/AvgZFOayJWvRQ8IjDKSaJsS+/s="
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1607579099031302147",
                "tweetText" : "Rebound bullet to kill enemy",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Evony - The King's Return",
                "screenName" : "@Evony_TKR"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Evony: The King's Return ANDROID All"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "Android Lollipop and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Android"
                }
              ],
              "impressionTime" : "2023-05-24 06:13:30"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "LoveMake.eth",
                "screenName" : "@g13m"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                }
              ],
              "impressionTime" : "2023-05-25 13:07:18"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "aramco",
                "screenName" : "@aramco"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                }
              ],
              "impressionTime" : "2023-05-25 13:07:17"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Bitget",
                "screenName" : "@bitgetglobal"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Business & finance"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Elon Musk"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Cryptocurrencies"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                }
              ],
              "impressionTime" : "2023-05-27 18:26:28"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileTweets",
              "promotedTweetInfo" : {
                "tweetId" : "1661990550424395777",
                "tweetText" : "We are officially launching the Fire Minting Experience on @0xPolygonLabs!\n\nTo show web3 users how Fire protects users from frauds by simulating contracts before you sign, we've created a Minting Site where you can mint the free Fire NFT!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Fire",
                "screenName" : "@_joinfire"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2023-05-27 18:26:39"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Bitget",
                "screenName" : "@bitgetglobal"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Business & finance"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Elon Musk"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Cryptocurrencies"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2023-05-27 18:26:21"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Bitget",
                "screenName" : "@bitgetglobal"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Business & finance"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Elon Musk"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Cryptocurrencies"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2023-05-27 18:26:22"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Bitget",
                "screenName" : "@bitgetglobal"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Business & finance"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Elon Musk"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Cryptocurrencies"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                }
              ],
              "impressionTime" : "2023-05-27 18:26:28"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Bitget",
                "screenName" : "@bitgetglobal"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Business & finance"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Elon Musk"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Cryptocurrencies"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                }
              ],
              "impressionTime" : "2023-06-01 15:57:30"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Android",
                "deviceId" : "RI7zRRFAi6bh65Z6/AvgZFOayJWvRQ8IjDKSaJsS+/s="
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1664139995979059201",
                "tweetText" : "Check out this exclusive app offer by IndiGo! You can get up to ₹500 off on your international flights and up to ₹350 off on domestic flights now. \n#TapMyApp #goIndiGo",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "IndiGo",
                "screenName" : "@IndiGo6E"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Android"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                }
              ],
              "impressionTime" : "2023-06-05 14:31:03"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Android",
                "deviceId" : "RI7zRRFAi6bh65Z6/AvgZFOayJWvRQ8IjDKSaJsS+/s="
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1666065296413667329",
                "tweetText" : "Offer your ride fare, get offers from drivers, and pick the one you like best 😍",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "inDrive",
                "screenName" : "@inDrive"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install inDrive. Rides with fair fares ANDROID All"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Android"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Mumbai"
                }
              ],
              "impressionTime" : "2023-06-06 13:00:18"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Snapdragon India",
                "screenName" : "@Snapdragon_IN"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                }
              ],
              "impressionTime" : "2023-07-06 13:01:39"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1661997868042039296",
                "tweetText" : "Follow @snapdragon_in to be a part of Snapdragon Insider and connect with like-minded gaming fanatics.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Snapdragon India",
                "screenName" : "@Snapdragon_IN"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                }
              ],
              "impressionTime" : "2023-07-07 04:34:57"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Snapdragon India",
                "screenName" : "@Snapdragon_IN"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                }
              ],
              "impressionTime" : "2023-07-07 04:34:56"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Ragnarok Landverse",
                "screenName" : "@ROLandverse"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 49"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                }
              ],
              "impressionTime" : "2023-07-09 06:41:35"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Snapdragon India",
                "screenName" : "@Snapdragon_IN"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                }
              ],
              "impressionTime" : "2023-07-09 06:40:55"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Snapdragon India",
                "screenName" : "@Snapdragon_IN"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                }
              ],
              "impressionTime" : "2023-07-10 15:52:59"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Bitget",
                "screenName" : "@bitgetglobal"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Business & finance"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Cryptocurrencies"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                }
              ],
              "impressionTime" : "2023-04-28 17:08:23"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Bitget",
                "screenName" : "@bitgetglobal"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Business & finance"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Cryptocurrencies"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                }
              ],
              "impressionTime" : "2023-04-28 17:08:22"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Snapdragon India",
                "screenName" : "@Snapdragon_IN"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                }
              ],
              "impressionTime" : "2023-04-28 17:09:39"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Snapdragon India",
                "screenName" : "@Snapdragon_IN"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                }
              ],
              "impressionTime" : "2023-07-12 22:23:44"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Android",
                "deviceId" : "RI7zRRFAi6bh65Z6/AvgZFOayJWvRQ8IjDKSaJsS+/s="
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1651342159440928769",
                "tweetText" : "It's official, @dawufi is bringing OAK's on-chain automation to #Consensus2023!\n\nWhether it's meeting w/ @Polkadot partners or collaborating w/ community builders like @TheCryptoKrill, the team is proud to be showcasing the power of on-chain automation!\n\nFollow us to learn more! https://t.co/DMG6qczFxT",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/DMG6qczFxT",
                  "https://t.co/DMG6qczFxT"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "OAK Network",
                "screenName" : "@oak_network"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 49"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                }
              ],
              "impressionTime" : "2023-04-29 19:54:25"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Islamic Coin",
                "screenName" : "@Islamic_Coin"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                }
              ],
              "impressionTime" : "2023-04-29 16:22:07"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Android",
                "deviceId" : "RI7zRRFAi6bh65Z6/AvgZFOayJWvRQ8IjDKSaJsS+/s="
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1642931399941406747",
                "tweetText" : "How to earn more with just $50? \n1)Install Vantage \n2) Choose an account type \n3) Fund your account \n4) Start trading \nLearn more &gt;&gt;",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "VantageApp",
                "screenName" : "@Vantage_trade"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Vantage:All-In-One Trading App ANDROID 30 Day"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Android"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "Android Oreo and above"
                }
              ],
              "impressionTime" : "2023-04-30 15:09:39"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "aramco",
                "screenName" : "@aramco"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                }
              ],
              "impressionTime" : "2023-05-04 10:40:11"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Snapdragon India",
                "screenName" : "@Snapdragon_IN"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                }
              ],
              "impressionTime" : "2023-05-04 11:52:29"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "LoveMake.eth",
                "screenName" : "@g13m"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                }
              ],
              "impressionTime" : "2023-05-05 16:02:47"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Snapdragon India",
                "screenName" : "@Snapdragon_IN"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                }
              ],
              "impressionTime" : "2023-05-06 14:24:08"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Android",
                "deviceId" : "RI7zRRFAi6bh65Z6/AvgZFOayJWvRQ8IjDKSaJsS+/s="
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1476173919543513090",
                "tweetText" : "An accomplishment for the Muslim World League is the extraction of more than 5055 approved authorizations with a direct chain of transmission to the Messenger of Allah (PBUH).  Follow the account for more about our Quranic programs in 78 countries.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Mohammed Al-Issa محمد العيسى",
                "screenName" : "@MhmdAlissa"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                }
              ],
              "impressionTime" : "2023-05-12 17:41:57"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Bitget",
                "screenName" : "@bitgetglobal"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Business & finance"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Elon Musk"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Cryptocurrencies"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2023-05-21 19:59:11"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Bitget",
                "screenName" : "@bitgetglobal"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Business & finance"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Elon Musk"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Cryptocurrencies"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "India"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2023-05-21 19:59:11"
            }
          ]
        }
      }
    }
  }
]