window.YTD.key_registry.part0 = [
  {
    "registeredDevices" : {
      "userId" : "1639610498680492032",
      "deviceMetadataList" : [
        {
          "userAgent" : "TwitterAndroid/9.88.0-release.0 (29880000-r-0) M2101K6P/12 (Xiaomi;M2101K6P;Redmi;sweetin;0;;1;2016)",
          "registrationToken" : "b2da2240e4552ffeb9569916f21cd1c9",
          "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEZ3AnwQ7PbixIqL6CpMBA6nP+gEVknlK+0sktWRLQfXoDZLbchJHAfLoalhnaRHDIlEjUuxH3EQx7bDaj/RKIvQ==",
          "createdAt" : "2023-05-16T15:35:09.422Z",
          "deviceId" : "06266729-cf66-4aa5-bf2b-526fa4208b0c"
        },
        {
          "userAgent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
          "registrationToken" : "00b86f1f68f84a87ebf868001cc5fe9b",
          "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEqcjEJRO614ZLUIyzt8JLrdPr+RVpt4frQUIPVvujFyV+ie+HmZiScv9542Z/HrE+PpYBL60Aphf3IaixG9ecDw==",
          "createdAt" : "2023-07-06T13:01:30.007Z",
          "deviceId" : "1f2c4e76-62fc-45dc-9d79-06b03dc902d2"
        },
        {
          "userAgent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
          "registrationToken" : "76e6f2a1dbebf58109b75247dc2b6054",
          "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEGAr960rRKX/6/Tsd+FMisGR+LybAQ7+dm38lcS8GkTyznVi2EUQoOPYcn0jRVtj/x3nTIbJ3ME+W1EOf+TChMQ==",
          "createdAt" : "2023-07-17T10:23:38.397Z",
          "deviceId" : "315eae69-def3-4103-9103-eb8d5cfabe35"
        },
        {
          "userAgent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
          "registrationToken" : "9ff09a18a03c783b7492fc35d2048488",
          "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE3vhgjv7FQPXdXDfMifjRzGeiWTbrophwJb6/uPgu6PJd3c2wRWPYuSFj4Yrz9CI0l31NxkqiDd2VBcKzFY4mBA==",
          "createdAt" : "2023-07-12T22:23:43.738Z",
          "deviceId" : "39c7383d-8aeb-44c5-a1c8-22fbaa504a5b"
        },
        {
          "userAgent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36",
          "registrationToken" : "de3094389b7a3dd19b19289e29ec7af4",
          "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEAV0To2rpqaEds0y/UQQkcCoqtgPBPsLP7RRxouJIajgK0AEpgnvApiUytNflhqV3IlYXLi8KQy8jx8FCWSJf/A==",
          "createdAt" : "2023-05-21T19:59:09.423Z",
          "deviceId" : "aaa5ac7e-7c9c-4fad-bafa-99fd8f559098"
        },
        {
          "userAgent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
          "registrationToken" : "0f6c3479f15bc0d225596a73c3da1250",
          "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE98pbB1J9nA1SzSBouJGh9sZ4H4qHHJZEni/pQ4M8QlbpbhLDlIMK31wstvFZkkm9OClQ2WEH/E5iUblXUtNXsQ==",
          "createdAt" : "2023-07-10T15:52:58.593Z",
          "deviceId" : "e468f803-438f-4f51-afd3-acf18ed2d987"
        }
      ]
    }
  }
]