window.YTD.like.part0 = [
  {
    "like" : {
      "tweetId" : "1680692891142746113",
      "fullText" : "https://t.co/04lWcL7QFk",
      "expandedUrl" : "https://twitter.com/i/web/status/1680692891142746113"
    }
  },
  {
    "like" : {
      "tweetId" : "1652580317058813954",
      "fullText" : "https://t.co/PoRcUYqa6b",
      "expandedUrl" : "https://twitter.com/i/web/status/1652580317058813954"
    }
  },
  {
    "like" : {
      "tweetId" : "1652278703802466310",
      "fullText" : "GM. https://t.co/kx77VFQVWm",
      "expandedUrl" : "https://twitter.com/i/web/status/1652278703802466310"
    }
  },
  {
    "like" : {
      "tweetId" : "1649579313061154817",
      "fullText" : "Starship liftoff in slow motion https://t.co/KqHjqwP88Z",
      "expandedUrl" : "https://twitter.com/i/web/status/1649579313061154817"
    }
  },
  {
    "like" : {
      "tweetId" : "1649632687680880640",
      "fullText" : "@charliesheen I feel your pain",
      "expandedUrl" : "https://twitter.com/i/web/status/1649632687680880640"
    }
  },
  {
    "like" : {
      "tweetId" : "1649565627177390080",
      "fullText" : "dear @elonmusk \ni’m sorry your fancy rocket\nexploded in spectacular fashion. I’m certain you’ll build an even bigger and more explody one.\n\nnow, \nmay i please have my \nblue check back?\nit would mean a lot to me.\n\nthank you in advance,\nsincerely - c sheen",
      "expandedUrl" : "https://twitter.com/i/web/status/1649565627177390080"
    }
  },
  {
    "like" : {
      "tweetId" : "1648619055882948609",
      "fullText" : "ChatGPT occasionally lies. Truly. It fabricated a reference entirely when I was looking up Penrose and Hameroff. When I called it on it, it apologized, but refused to explain itself, although it said it would not do so anymore in the future (after I told it not to). WTF? Here is…",
      "expandedUrl" : "https://twitter.com/i/web/status/1648619055882948609"
    }
  }
]