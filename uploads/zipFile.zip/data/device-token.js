window.YTD.device_token.part0 = [
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "UBaClIKU6Um6YEU8aHE8H8JxPeIwjF0cYdXyj4OX",
      "createdAt" : "2023-03-25T12:49:49.944Z",
      "lastSeenAt" : "2023-03-25T12:49:49.945Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "258901",
      "token" : "t4cOnVGIjnBr1o9vZagWTRHVwzrAtWcuXrKknAwK",
      "createdAt" : "2023-04-11T19:34:20.486Z",
      "lastSeenAt" : "2023-04-11T19:35:05.607Z",
      "clientApplicationName" : "Twitter for Android (Twitter, Inc.)"
    }
  }
]